<?php $__env->startSection('title'); ?>
  Item list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_links'); ?>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("/")); ?>">Posts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("users")); ?>">Users</a>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<h1>Details</h1>

  <div class = "row" id="content">

    <!-- left column -->
    <div class="col-sm-6">

      <div class="post">
            <p><h3><?php echo e($post->post_title); ?></h3></p>
              <div class="author"><?php echo e($post->user_name); ?></div>
            <div class="message"><?php echo e($post->message); ?></div>
      </div>


      <!-- Loop to display coments for a Post -->
      <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="comment">
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" class="bi bi-chat-square-text-fill" viewBox="0 0 16 16">
          <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm3.5 1a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 2.5a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"/>
        </svg>

          <div class="comment-content">
            <div class="author"><?php echo e($comment->user_name); ?></div>
            <div class="message"><?php echo e($comment->comment_message); ?></div>
          </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    
        <!-- right column -->
        <div class="col-sm-6">

        <!-- form to create a comment -->
          <form method="post" action="<?php echo e(url("create_comment_action")); ?>">
            <?php echo e(csrf_field()); ?>

            <p>Comment on Post</p>
              <!-- send post_id with the form to be able to insert into DB with comment -->
              <input type="hidden" name="post_id" value="<?php echo e($post->post_id); ?>">
              <p>
                <label>Author</label>
                <input type="text" name="author">
              </p>
              <p>
                <label>Message</label>
                <textarea type="text" name="comment_message"></textarea>
              </p>
              <p>Date</p>
            <input type="submit" value="Comment">
          <!-- </form> -->
        </div>
  </div>

  <a href="<?php echo e(url("/")); ?>">Back</a>
</div><!-- /.container -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment1/resources/views/pages/post_detail.blade.php ENDPATH**/ ?>