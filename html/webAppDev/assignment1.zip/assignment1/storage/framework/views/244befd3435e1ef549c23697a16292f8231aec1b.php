<!-- Home Page -->



<?php $__env->startSection('title'); ?>
  Hompage - List of Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_links'); ?>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo e(url("/")); ?>">Posts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("users")); ?>">Users</a>
  </li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container">

<h1>Home Page - List of Posts</h1>

  <div class = "row" id="content">

    <!-- left column -->
    <div class="col-sm-6">

      <?php if($posts): ?>
        <ul>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="post">
            <div class="title"><a href="<?php echo e(url("post_detail/$post->post_id")); ?>"><?php echo e($post->post_title); ?></a></div>
            <div class="author"><?php echo e($post->user_name); ?></div>
            <div class="message"><?php echo e($post->message); ?></div>

              <!-- //Delete Post Button -->
              <div class="delete">
              <a href="<?php echo e(url("delete_post/$post->post_id")); ?>">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash-circle-fill" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z"/>
              </svg>
                Delete</a>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
          No post found
      <?php endif; ?>

    </div>

    
        <!-- right column -->
        <div class="col-sm-6">

        <!-- form to create post -->
          <form method="post" action="<?php echo e(url("create_post_action")); ?>">
            <?php echo e(csrf_field()); ?>

              <p>
                <label>Post Title</label>
                <input type="text" name="post_title">
              </p>
              <p>
                <label>Author</label>
                <input type="text" name="author">
              </p>
              <p>
                <label>Message</label>
                <textarea type="text" name="message"></textarea>
              </p>
            <input type="submit" value="Post">
          <!-- </form> -->
        </div>
  </div>
</div><!-- /.container -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment1/resources/views/pages/post_list.blade.php ENDPATH**/ ?>