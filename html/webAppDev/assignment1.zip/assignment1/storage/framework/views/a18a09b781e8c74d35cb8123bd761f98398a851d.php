<!-- Home Page -->



<?php $__env->startSection('title'); ?>
  Users - List of Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_links'); ?>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("/")); ?>">Posts</a>
  </li>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo e(url("users")); ?>">Users</a>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Users - List of Users</h1>

      <?php if($users): ?>
        <ul>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div id="user">
            <div id="user"><?php echo e($user->user_name); ?>

              <!-- //Delete Post Button -->
              <div class="delete">
                <a href="<?php echo e(url("delete_user/$user->user_name")); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash-circle-fill" viewBox="0 0 16 16">
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM4.5 7.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1h-7z"/>
                </svg>
                  Delete</a>
              </div>
            </div>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
          No post found
      <?php endif; ?>

    </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment1/resources/views/pages/users.blade.php ENDPATH**/ ?>