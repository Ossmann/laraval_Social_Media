<?php $__env->startSection('title'); ?>
  Add Item
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Add Item</h1>
  <form method="post" action="<?php echo e(url("add_item_action")); ?>">
    <?php echo e(csrf_field()); ?>

    <p>
    <label>Summary</label>
    <input type="text" name="summary">
    </p>
    <p>
    <label>Details</label>
    <textarea type="text" name="details"></textarea>
    </p>
    <input type="submit" value="Add">

  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week6/items/resources/views/items/add_item.blade.php ENDPATH**/ ?>