<?php $__env->startSection('title'); ?>
  Item list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <p><h1><?php echo e($item->summary); ?></h1></p>
    <p><?php echo e($item->details); ?></p>

    <!-- Look into the lecture notes how to delet -->
    <a href="<?php echo e(url("delete_item/$item->id")); ?>">Delete this item</a> <br><br>
    <a href="<?php echo e(url("update_item/$item->id")); ?>">Update this item</a> <br><br>
    
    <a href="<?php echo e(url("/")); ?>">Home</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week6/items/resources/views/items/item_detail.blade.php ENDPATH**/ ?>