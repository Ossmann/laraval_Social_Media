<?php $__env->startSection('title'); ?>
  Item list
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_links'); ?>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("/")); ?>">Posts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("users")); ?>">Users</a>
  </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php dump($post); ?>
<?php dump($comments); ?>

<div class="container">
<h1>Details</h1>

  <div class = "row" id="content">

    <!-- left column -->
    <div class="col-sm-6">

      <div class="post">
            <p><h3><?php echo e($post->post_title); ?></h3></p>
              <div class="author"><?php echo e($post->user_name); ?></div>
              <div class="date"><?php echo e($post->date); ?></div>
            <div class="message"><?php echo e($post->message); ?></div>


              <!-- //Like Button ?? CHECK IF here we can Like aswell --> 
              <div class="like">
                <div class="like_button">
                <i class="bi bi-hand-thumbs-up-fill"></i>
                </div>
                <!-- Like counter -->
              </div>
      </div>
      <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment">
          <div class="commentline">
            <i class="bi bi-chat-right-text-fill"></i>
            <div class="comment-content">
              <div class="topline">
                <div class="author"><?php echo e($comment->user_name); ?></div>
                <div class="date"><?php echo e($comment->date); ?></div>
              </div>
              <div class="message"><?php echo e($comment->comment_message); ?></div>
            </div>
          </div>

          <!-- Reply Button with bootstrap Modal -->
          <div class="reply">

            <!-- Button trigger modal -- add the comment variable to the data target -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($comment->comment_id); ?>">
            <i class="bi bi-reply-all-fill"></i>Reply</a>
            </button>

            

            <!-- Modal -->
            <div class="modal fade" id="exampleModal<?php echo e($comment->comment_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">What do you want to reply to <?php echo e($comment->user_name); ?>?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                  <?php dump($comment->comment_id); ?>
                  <form method="post" action="<?php echo e(url('create_reply_action/' . $comment->post_id . '/' . $comment->comment_id)); ?>">
                      <?php echo e(csrf_field()); ?>

                      <p>
                        <label>Your Username</label>
                        <input type="text" name="author">
                      </p>
                      <p>
                        <label>Reply</label>
                        <textarea type="text" name="reply_message"></textarea>
                      </p>
                        <input type="submit" value="Reply">
                    </form>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          

        </div>

        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="reply">
          <div class="replyline">
            <div class="reply-content">
              <div class="topline">
                <div class="author"><?php echo e($reply->user_name); ?></div>
                <div class="date"><?php echo e($reply->date); ?></div>
              </div>
              <div class="message"><?php echo e($reply->reply_message); ?></div>
            </div>
            <div class="reply_icon">
              <i class="bi bi-chat-left-text"></i>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    
        <!-- right column -->
        <div class="col-sm-6">

        <!-- form to create a comment -->
          <form method="post" action="<?php echo e(url("create_comment_action")); ?>">
            <?php echo e(csrf_field()); ?>

            <p>Comment on Post</p>
              <!-- send post_id with the form to be able to insert into DB with comment -->
              <input type="hidden" name="post_id" value="<?php echo e($post->post_id); ?>">
              <p>
                <label>Author</label>
                <input type="text" name="author">
              </p>
              <p>
                <label>Message</label>
                <textarea type="text" name="comment_message"></textarea>
              </p>
            <input type="submit" value="Comment">
          </form>
        </div>
  </div>

  <a href="<?php echo e(url("/")); ?>">Back</a>
</div><!-- /.container -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment1/resources/views/pages/post_detail.blade.php ENDPATH**/ ?>