<!-- Home Page -->



<?php $__env->startSection('title'); ?>
  Hompage - List of Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav_links'); ?>
  <li class="nav-item active">
    <a class="nav-link" href="<?php echo e(url("/")); ?>">Posts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url("users")); ?>">Users</a>
  </li>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container">
<?php dump($posts); ?>
<h1>Home Page - List of Posts</h1>

  <div class = "row" id="content">

    <!-- left column -->
    <div class="col-sm-6">

      <?php if($posts): ?>
        <ul>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="post">
            <div class="topline">
              <div class="title"><a href="<?php echo e(url("post_detail/$post->post_id")); ?>"><?php echo e($post->post_title); ?></a>

                <!-- Comment Counter -->
                <div class="comment_counter">
                  <i class="bi bi-chat-left-text"></i>
                  <?php echo e($post->comment_counter); ?>

                </div>
              </div>
              <div class="date"><?php echo e($post->date); ?></div>
            </div>
            
            <div class="author"><?php echo e($post->user_name); ?></div>

            <!-- Condition either Author form or Like Button with Button to add author -->
            <?php if($like_toggle): ?>
              <form method="post" action="<?php echo e(url("create_like_action")); ?>">
                <?php echo e(csrf_field()); ?>

                  <p>
                    <input type="text" name="author" placeholder="Enter user name">
                  </p>
                <input type="submit" value="Like">
              </form>
            <?php else: ?>
              <!-- //Like Button -->
              <div class="like">
                <div class="like_button">
                <a class="nav-link" href="<?php echo e(url("/like_input")); ?>"><i class="bi bi-hand-thumbs-up-fill"></i></a>
                </div>
                <?php echo e($post->like_counter); ?>

              </div>
            <?php endif; ?>

              <!-- //Delete Post Button -->
              <div class="delete">
              <a href="<?php echo e(url("delete_post/$post->post_id")); ?>">
                <i class="bi bi-dash-circle-fill"></i>
                Delete</a>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php else: ?>
          No post found
      <?php endif; ?>

    </div>

    
        <!-- right column -->
        <div class="col-sm-6">

        <!-- form to create post -->
          <form method="post" action="<?php echo e(url("create_post_action")); ?>">
            <?php echo e(csrf_field()); ?>

              <p>
                <label>Post Title</label>
                <input type="text" name="post_title">
              </p>
              <p>
                <label>Author</label>
                <input type="text" name="author">
              </p>
              <p>
                <label>Message</label>
                <textarea type="text" name="message"></textarea>
              </p>
            <input type="submit" value="Post">
          </form>
        </div>
  </div>
</div><!-- /.container -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment1/resources/views/pages/post_list.blade.php ENDPATH**/ ?>