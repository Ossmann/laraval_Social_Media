<html>
  <head>
    <title>Greeting</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/wp.css')); ?>">
  </head>
  
  <body>  
    <p>
    Hello <?php echo e($user); ?>.
    Next year, you will be <?php echo e($age); ?> years old.

    <hr>
    <p><a href="show.php?file=greeting.php">Source</a></p>
  </body>
</html><?php /**PATH /var/www/html/webAppDev/week4/task2 - greeting-laravel/resources/views/greeting.blade.php ENDPATH**/ ?>