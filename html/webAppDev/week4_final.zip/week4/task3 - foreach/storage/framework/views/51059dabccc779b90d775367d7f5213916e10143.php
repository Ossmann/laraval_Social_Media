
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Foreach loop example</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/wp.css')); ?>" type="text/css">

    </head>
    <body>
            <table class="bordered">
                    <!-- table header -->
                    <tr><th>Name</th><th>Value</th></tr>
            <?php $__empty_1 = true; $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($loop->index %2 == 0): ?>
                        <tr class="alt"><td><?php echo e($name); ?>:</td><td><?php echo e($value); ?></td></tr>
                    <?php else: ?>
                        <tr><td><?php echo e($name); ?>:</td><td><?php echo e($value); ?></td></tr>
                    <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan=2>No URL variable</td></tr>
            <?php endif; ?>
            </table>
    </body>
</html><?php /**PATH /var/www/html/webAppDev/week4/task3 - foreach/resources/views/foreach.blade.php ENDPATH**/ ?>