<?php $__env->startSection('title'); ?>
  Australian Prime Ministers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h2>Australian Prime Ministers</h2>
    <p>Your search results.</p>

    <table class="bordered">
    <!-- table header -->
    <tr>
        <th>No.</th>
        <th>Name</th>
        <th>From</th>
        <th>To</th>
        <th>Duration</th>
        <th>Party</th>
        <th>State</th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $pms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($pm['index']); ?></td>
            <td><?php echo e($pm['name']); ?></td>
            <td><?php echo e($pm['from']); ?></td>
            <td><?php echo e($pm['to']); ?></td>
            <td><?php echo e($pm['duration']); ?></td>
            <td><?php echo e($pm['party']); ?></td>
            <td><?php echo e($pm['state']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7">No data available</td>
        </tr>
    <?php endif; ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task5/assoc-laravel/resources/views/results.blade.php ENDPATH**/ ?>