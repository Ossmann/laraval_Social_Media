<?php $__env->startSection('title'); ?>
  Australian Prime Ministers
  Query
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <h2>Australian Prime Ministers</h2>
  <h3>Query</h3>
  <!-- Include to prevent cross site referencing attack -->
  <?php echo e(csrf_field()); ?>


  <form method="get" action="results">
  <table>
    <tr><td>Name: </td><td><input type="text" name="name"></td></tr>
    <tr><td>Year: </td><td><input type="text" name="year"></td></tr>
    <tr><td>State: </td><td><input type="text" name="state"></td></tr>
    <tr><td colspan=2><input type="submit" value="Search">
                      <input type="reset" value="Reset"></td></tr>
  <table>
  </form>

  <hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task5/assoc-laravel/resources/views/searchForm.blade.php ENDPATH**/ ?>